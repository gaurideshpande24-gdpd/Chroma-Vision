import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";
import { Logo } from "@/components/Logo";
import { HistogramCanvas } from "@/components/HistogramCanvas";
import {
  defaultProfile, loadProfile, saveProfile,
  recordStrengthChange, recordModeUsage,
  type UserProfile,
} from "@/lib/colorease/profile";
import { simulateInPlace, daltonizeInPlace } from "@/lib/colorease/daltonize";
import { MODES } from "@/lib/colorease/modes";
import type { AccessibilityMode } from "@/lib/colorease/profile";
import { histogram, type Histogram } from "@/lib/colorease/histogram";
import { centerColor, nameColor } from "@/lib/colorease/colorName";
import { speak, stopSpeaking } from "@/lib/colorease/voice";
import type { Deficiency } from "@/lib/colorease/simulation";

import { AdvancedAnalysisPanel } from "@/components/AdvancedAnalysisPanel";
import { PixelInspector } from "@/components/PixelInspector";
import { enhancedDaltonize } from "@/lib/colorease/advancedVision";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Live Dashboard — ColorEase" },
      { name: "description", content: "Real-time camera dashboard with original, simulated color-blind, and AI-corrected vision side by side." },
      { property: "og:title", content: "ColorEase Live Vision Dashboard" },
      { property: "og:description", content: "Original, simulated, and AI-corrected vision — live, side by side." },
    ],
  }),
  component: DashboardPage,
});

const PROC_W = 480;
const PROC_H = 360;

function toGray(src: Uint8ClampedArray): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src.length);
  for (let i = 0; i < src.length; i += 4) {
    const v = Math.round(0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2]);
    out[i] = out[i + 1] = out[i + 2] = v; out[i + 3] = 255;
  }
  return out;
}

function equalizeChannel(data: Uint8ClampedArray): Uint8ClampedArray {
  const out = new Uint8ClampedArray(data.length);
  const hist = [new Array(256).fill(0), new Array(256).fill(0), new Array(256).fill(0)];
  const total = data.length / 4;
  for (let i = 0; i < data.length; i += 4) {
    hist[0][data[i]]++; hist[1][data[i + 1]]++; hist[2][data[i + 2]]++;
  }
  const lut = hist.map((h) => {
    let acc = 0;
    return h.map((v) => { acc += v; return Math.round((acc / total) * 255); });
  });
  for (let i = 0; i < data.length; i += 4) {
    out[i] = lut[0][data[i]]; out[i + 1] = lut[1][data[i + 1]]; out[i + 2] = lut[2][data[i + 2]]; out[i + 3] = 255;
  }
  return out;
}

const K3 = [1, 2, 1, 2, 4, 2, 1, 2, 1];

function blur3(src: Uint8ClampedArray, w: number, h: number): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src.length);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let sr = 0, sg = 0, sb = 0, ws = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const ny = Math.min(h - 1, Math.max(0, y + ky));
          const nx = Math.min(w - 1, Math.max(0, x + kx));
          const ni = (ny * w + nx) * 4;
          const kw = K3[(ky + 1) * 3 + (kx + 1)];
          sr += src[ni] * kw; sg += src[ni + 1] * kw; sb += src[ni + 2] * kw; ws += kw;
        }
      }
      const i = (y * w + x) * 4;
      out[i] = sr / ws; out[i + 1] = sg / ws; out[i + 2] = sb / ws; out[i + 3] = 255;
    }
  }
  return out;
}

function sharpenedImg(src: Uint8ClampedArray, w: number, h: number): Uint8ClampedArray {
  const bl = blur3(src, w, h);
  const out = new Uint8ClampedArray(src.length);
  for (let i = 0; i < src.length; i += 4) {
    out[i] = Math.min(255, Math.max(0, src[i] + 1.2 * (src[i] - bl[i])));
    out[i + 1] = Math.min(255, Math.max(0, src[i + 1] + 1.2 * (src[i + 1] - bl[i + 1])));
    out[i + 2] = Math.min(255, Math.max(0, src[i + 2] + 1.2 * (src[i + 2] - bl[i + 2])));
    out[i + 3] = 255;
  }
  return out;
}

function edgeMap(src: Uint8ClampedArray, w: number, h: number): Uint8ClampedArray {
  const gray = new Uint8ClampedArray(w * h);
  for (let i = 0; i < w * h; i++) gray[i] = Math.round(0.299 * src[i * 4] + 0.587 * src[i * 4 + 1] + 0.114 * src[i * 4 + 2]);
  const Gx = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
  const Gy = [-1, -2, -1, 0, 0, 0, 1, 2, 1];
  const out = new Uint8ClampedArray(src.length);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let gx = 0, gy = 0;
      for (let ky = -1; ky <= 1; ky++) {
        for (let kx = -1; kx <= 1; kx++) {
          const k = (ky + 1) * 3 + (kx + 1);
          const v = gray[Math.min(h - 1, Math.max(0, y + ky)) * w + Math.min(w - 1, Math.max(0, x + kx))];
          gx += v * Gx[k]; gy += v * Gy[k];
        }
      }
      const v = Math.min(255, Math.abs(gx) + Math.abs(gy));
      const i = (y * w + x) * 4;
      out[i] = v; out[i + 1] = v; out[i + 2] = v; out[i + 3] = 255;
    }
  }
  return out;
}

function toHSV(src: Uint8ClampedArray): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src.length);
  for (let i = 0; i < src.length; i += 4) {
    const r = src[i] / 255, g = src[i + 1] / 255, b = src[i + 2] / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    let h = 0;
    if (d !== 0) {
      if (max === r) h = ((g - b) / d + 6) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h /= 6;
    }
    out[i] = Math.round(h * 255);
    out[i + 1] = Math.round((max === 0 ? 0 : d / max) * 255);
    out[i + 2] = Math.round(max * 255);
    out[i + 3] = 255;
  }
  return out;
}

function toLAB(src: Uint8ClampedArray): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src.length);
  const lin = (c: number) => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const f = (t: number) => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
  for (let i = 0; i < src.length; i += 4) {
    const r = lin(src[i]), g = lin(src[i + 1]), b = lin(src[i + 2]);
    const X = f((0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047);
    const Y = f((0.2126 * r + 0.7152 * g + 0.0722 * b));
    const Z = f((0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883);
    out[i] = Math.min(255, Math.max(0, (116 * Y - 16) * 2.55));
    out[i + 1] = Math.min(255, Math.max(0, 500 * (X - Y) + 128));
    out[i + 2] = Math.min(255, Math.max(0, 200 * (Y - Z) + 128));
    out[i + 3] = 255;
  }
  return out;
}

interface PanelSet {
  original: ImageData; recolored: ImageData; equalized: ImageData;
  denoised: ImageData; edges: ImageData; sharpened: ImageData;
  gray: ImageData; hsv: ImageData; lab: ImageData;
  hist: { original: Histogram; recolored: Histogram; equalized: Histogram; denoised: Histogram; edges: Histogram; sharpened: Histogram; };
}

function buildPanelSet(orig: ImageData, type: Deficiency, severity: number): PanelSet {
  const W = orig.width, H = orig.height;
  const corrD = new Uint8ClampedArray(orig.data);
  daltonizeInPlace(corrD, { type, severity, strength: 1.2, contrast: 0.4, saturation: 0.4 });
  const mk = (d: Uint8ClampedArray) => new ImageData(new Uint8ClampedArray(d), W, H);
  const eqD = equalizeChannel(orig.data);
  const denD = blur3(corrD, W, H);
  const edgeD = edgeMap(orig.data, W, H);
  const sharpD = sharpenedImg(corrD, W, H);
  const grayD = toGray(orig.data);
  const hsvD = toHSV(orig.data);
  const labD = toLAB(orig.data);
  return {
    original: orig, recolored: mk(corrD), equalized: mk(eqD), denoised: mk(denD),
    edges: mk(edgeD), sharpened: mk(sharpD), gray: mk(grayD), hsv: mk(hsvD), lab: mk(labD),
    hist: {
      original: histogram(orig), recolored: histogram(mk(corrD)), equalized: histogram(mk(eqD)),
      denoised: histogram(mk(denD)), edges: histogram(mk(edgeD)), sharpened: histogram(mk(sharpD)),
    },
  };
}

function MiniImagePanel({ label, imgData, histData }: { label: string; imgData: ImageData | null; histData?: Histogram | null }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!ref.current || !imgData) return;
    const c = ref.current;
    c.width = imgData.width; c.height = imgData.height;
    c.getContext("2d")!.putImageData(imgData, 0, 0);
  }, [imgData]);
  return (
    <div className="flex flex-col gap-1">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <canvas ref={ref} className="w-full rounded-lg border border-border" style={{ aspectRatio: "4/3", objectFit: "cover" }} />
      {histData && <HistogramCanvas data={histData} label="" />}
    </div>
  );
}

function ImageAnalysisSection({ cvdType, cvdSeverity }: { cvdType: Deficiency; cvdSeverity: number }) {
  const [analyzed, setAnalyzed] = useState<Array<{ name: string; panels: PanelSet }>>([]);
  const [dragging, setDragging] = useState(false);
  const [processing, setProcessing] = useState(false);

  const processFiles = useCallback(async (files: FileList | File[]) => {
    setProcessing(true);
    const arr = Array.from(files).filter((f) => f.type.startsWith("image/"));
    for (const file of arr) {
      const url = URL.createObjectURL(file);
      const img = await new Promise<HTMLImageElement>((res) => {
        const el = new Image(); el.onload = () => res(el); el.src = url;
      });
      const W = Math.min(img.naturalWidth, 480);
      const H = Math.round(img.naturalHeight * (W / img.naturalWidth));
      const canvas = document.createElement("canvas");
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, W, H);
      const orig = ctx.getImageData(0, 0, W, H);
      URL.revokeObjectURL(url);
      const panels = buildPanelSet(orig, cvdType, cvdSeverity);
      setAnalyzed((prev) => [...prev, { name: file.name, panels }]);
    }
    setProcessing(false);
  }, [cvdType, cvdSeverity]);

  return (
    <section className="lg:col-span-12 glow-card p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-display font-bold text-base">Multi-Image Analysis</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Upload any number of images — each renders the full panel grid using the active CVD mode ({displayType(cvdType)}).
          </p>
        </div>
        {analyzed.length > 0 && (
          <button onClick={() => setAnalyzed([])} className="btn-ghost-rainbow !py-1.5 !px-3 text-xs">Clear all</button>
        )}
      </div>
      <label
        className={`flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed py-10 cursor-pointer transition ${dragging ? "border-[var(--spec-blue)] bg-blue-50/30" : "border-border hover:border-foreground/30"}`}
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); if (e.dataTransfer.files.length) processFiles(e.dataTransfer.files); }}
      >
        <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => { if (e.target.files?.length) processFiles(e.target.files); }} />
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-muted-foreground">
          <rect x="3" y="3" width="18" height="18" rx="3" /><path d="M3 16l5-5 4 4 3-3 4 4" /><circle cx="8.5" cy="8.5" r="1.5" />
        </svg>
        <span className="text-sm text-muted-foreground">Drag & drop images or <span className="text-foreground font-medium">click to browse</span></span>
        <span className="text-[11px] text-muted-foreground">PNG · JPG · WEBP — any number</span>
        {processing && <span className="text-[11px] text-[var(--spec-blue)]">Processing…</span>}
      </label>
      {analyzed.map(({ name, panels }, i) => (
        <div key={i} className="space-y-3 border-t border-border pt-5">
          <div className="flex items-center gap-2">
            <span className="font-medium text-sm truncate max-w-xs">{name}</span>
            <button onClick={() => setAnalyzed((p) => p.filter((_, j) => j !== i))} className="ml-auto shrink-0 text-[11px] text-muted-foreground hover:text-foreground">Remove</button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <MiniImagePanel label="Original" imgData={panels.original} histData={panels.hist.original} />
            <MiniImagePanel label="Recolored" imgData={panels.recolored} histData={panels.hist.recolored} />
            <MiniImagePanel label="Equalized" imgData={panels.equalized} histData={panels.hist.equalized} />
            <MiniImagePanel label="Denoised" imgData={panels.denoised} histData={panels.hist.denoised} />
            <MiniImagePanel label="Edges" imgData={panels.edges} histData={panels.hist.edges} />
            <MiniImagePanel label="Sharpened" imgData={panels.sharpened} histData={panels.hist.sharpened} />
            <MiniImagePanel label="Gray" imgData={panels.gray} />
            <MiniImagePanel label="HSV" imgData={panels.hsv} />
            <MiniImagePanel label="LAB" imgData={panels.lab} />
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Detected</span>
              <div className="w-full rounded-lg border border-border bg-muted/40 flex items-center justify-center text-xs text-muted-foreground" style={{ aspectRatio: "4/3" }}>Enable camera detection</div>
            </div>
          </div>
        </div>
      ))}
      {analyzed.length === 0 && !processing && (
        <p className="text-center text-xs text-muted-foreground py-2">No images analysed yet.</p>
      )}
    </section>
  );
}

function CVDSimulatorCard({ origCanvasRef }: { origCanvasRef: React.RefObject<HTMLCanvasElement> }) {
  const [simType, setSimType] = useState<Deficiency>("protan");
  const previewRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  useEffect(() => {
    let active = true;
    const loop = () => {
      if (!active) return;
      const src = origCanvasRef.current;
      const dst = previewRef.current;
      if (src && dst && src.width > 0) {
        dst.width = src.width; dst.height = src.height;
        const ctx = dst.getContext("2d", { willReadFrequently: true })!;
        ctx.drawImage(src, 0, 0);
        const id = ctx.getImageData(0, 0, dst.width, dst.height);
        simulateInPlace(id.data, simType, 1.0);
        ctx.putImageData(id, 0, 0);
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { active = false; cancelAnimationFrame(rafRef.current); };
  }, [simType, origCanvasRef]);
  const types: Array<{ key: Deficiency; label: string; desc: string; color: string }> = [
    { key: "protan", label: "Protanopia", desc: "Red-blind", color: "#ef4444" },
    { key: "deutan", label: "Deuteranopia", desc: "Green-blind", color: "#16a34a" },
    { key: "tritan", label: "Tritanopia", desc: "Blue-blind", color: "#2563eb" },
  ];
  return (
    <div className="glow-card p-5 space-y-4">
      <div>
        <h3 className="font-display font-bold">CVD Simulator</h3>
        <p className="text-[11px] text-muted-foreground mt-0.5">Simulate any type for demonstration</p>
      </div>
      <div className="flex gap-2">
        {types.map(({ key, label, desc, color }) => (
          <button key={key} onClick={() => setSimType(key)}
            className={`flex-1 rounded-xl border px-2 py-2 text-center text-[11px] transition ${simType === key ? "border-transparent text-white" : "border-border hover:border-foreground/20"}`}
            style={simType === key ? { background: color } : {}}>
            <div className="font-semibold">{label}</div>
            <div className={`text-[10px] ${simType === key ? "text-white/80" : "text-muted-foreground"}`}>{desc}</div>
          </button>
        ))}
      </div>
      <div className="overflow-hidden rounded-xl border border-border bg-black" style={{ aspectRatio: "4/3" }}>
        <canvas ref={previewRef} className="h-full w-full" />
      </div>
      <p className="text-[10px] text-muted-foreground text-center">Full-severity {types.find((t) => t.key === simType)?.label} simulation — for demonstration only</p>
    </div>
  );
}

// ─── MaximizeModal ─────────────────────────────────────────────────────────────

function MaximizeModal({
  label, subtitle, srcCanvasRef, overlayCanvasRef, onClose,
}: {
  label: string;
  subtitle: string;
  srcCanvasRef: React.RefObject<HTMLCanvasElement>;
  overlayCanvasRef?: React.RefObject<HTMLCanvasElement>;
  onClose: () => void;
}) {
  const bigCanvasRef = useRef<HTMLCanvasElement>(null);
  const bigOverlayRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const draw = () => {
      const src = srcCanvasRef.current;
      const dst = bigCanvasRef.current;
      if (src && dst && src.width > 0) {
        dst.width = src.width; dst.height = src.height;
        dst.getContext("2d")!.drawImage(src, 0, 0);
      }
      if (overlayCanvasRef?.current && bigOverlayRef.current) {
        const osrc = overlayCanvasRef.current;
        const odst = bigOverlayRef.current;
        odst.width = osrc.width; odst.height = osrc.height;
        odst.getContext("2d")!.drawImage(osrc, 0, 0);
      }
      rafRef.current = requestAnimationFrame(draw);
    };
    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, [srcCanvasRef, overlayCanvasRef]);

  useEffect(() => {
    const handle = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handle);
    return () => window.removeEventListener("keydown", handle);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-sm" onClick={onClose}>
      <div className="relative w-full max-w-6xl mx-4 rounded-2xl overflow-hidden border border-white/10 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between bg-black/70 px-4 py-2.5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="live-dot" />
            <span className="font-display font-bold text-white text-sm">{label}</span>
            <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] text-white/60">{subtitle}</span>
          </div>
          <button onClick={onClose} className="rounded-lg bg-white/10 hover:bg-white/20 px-3 py-1.5 text-[11px] text-white transition flex items-center gap-1.5">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12" /></svg>
            Close (Esc)
          </button>
        </div>
        <div className="relative bg-black" style={{ aspectRatio: "4/3" }}>
          <canvas ref={bigCanvasRef} className="h-full w-full object-contain" />
          {overlayCanvasRef && <canvas ref={bigOverlayRef} className="pointer-events-none absolute inset-0 h-full w-full object-contain" />}
        </div>
      </div>
      <p className="mt-3 text-[11px] text-white/30">Click outside or press Esc to close</p>
    </div>
  );
}

// ─── DashboardPage ────────────────────────────────────────────────────────────

function DashboardPage() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fps, setFps] = useState(0);
  const [latency, setLatency] = useState(0);
  const [centerName, setCenterName] = useState("—");
  const [hists, setHists] = useState<{ orig: Histogram | null; sim: Histogram | null; corr: Histogram | null }>({ orig: null, sim: null, corr: null });
  const [detections, setDetections] = useState<Array<{ class: string; score: number; bbox: [number, number, number, number] }>>([]);
  const [maximized, setMaximized] = useState<null | "original" | "simulated" | "corrected">(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const origCanvasRef = useRef<HTMLCanvasElement>(null);
  const simCanvasRef = useRef<HTMLCanvasElement>(null);
  const corrCanvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const detectorRef = useRef<{ detect: (c: HTMLCanvasElement) => Promise<unknown[]> } | null>(null);
  const profileRef = useRef<UserProfile | null>(null);

  useEffect(() => {
    const p = loadProfile() ?? defaultProfile();
    setProfile(p); profileRef.current = p;
  }, []);
  useEffect(() => { profileRef.current = profile; }, [profile]);

  useEffect(() => {
    let stream: MediaStream | null = null;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" }, audio: false,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setStreaming(true);
        }
      } catch (e) { setError(e instanceof Error ? e.message : "Camera unavailable"); }
    })();
    return () => { cancelAnimationFrame(rafRef.current); stopSpeaking(); stream?.getTracks().forEach((t) => t.stop()); };
  }, []);

  useEffect(() => {
    if (!profile?.detect) { detectorRef.current = null; return; }
    let cancelled = false;
    (async () => {
      try {
        const tf = await import("@tensorflow/tfjs"); await tf.ready();
        const cocoSsd = await import("@tensorflow-models/coco-ssd");
        const model = await cocoSsd.load({ base: "lite_mobilenet_v2" });
        if (!cancelled) detectorRef.current = { detect: (c) => model.detect(c) as unknown as Promise<unknown[]> };
      } catch { /* silent */ }
    })();
    return () => { cancelled = true; };
  }, [profile?.detect]);

  useEffect(() => {
    if (!streaming || !profile) return;
    const video = videoRef.current!;
    const oc = origCanvasRef.current!;
    const sc = simCanvasRef.current!;
    const cc = corrCanvasRef.current!;
    [oc, sc, cc].forEach((c) => { c.width = PROC_W; c.height = PROC_H; });
    const octx = oc.getContext("2d", { willReadFrequently: true })!;
    const sctx = sc.getContext("2d", { willReadFrequently: true })!;
    const cctx = cc.getContext("2d", { willReadFrequently: true })!;
    let frames = 0, lastFpsAt = performance.now(), lastVoiceAt = 0, lastDetectAt = 0, lastHistAt = 0;

    const tick = async () => {
      const t0 = performance.now();
      try {
        // ── Window 1: Original — raw camera feed, untouched ──
        octx.drawImage(video, 0, 0, PROC_W, PROC_H);
        const orig = octx.getImageData(0, 0, PROC_W, PROC_H);

        const p = profileRef.current!;
        const mode = MODES[p.mode];

        // ── Window 2: Simulated — full-severity CVD sim + desaturation crush
        // Forces minimum 85% severity so differences are always clearly visible.
        const simData = new ImageData(new Uint8ClampedArray(orig.data), PROC_W, PROC_H);
        simulateInPlace(simData.data, p.type, Math.max(0.85, p.severity));
        // Reduce channel variance so confusable colour pairs look nearly identical
        for (let i = 0; i < simData.data.length; i += 4) {
          const r = simData.data[i], g = simData.data[i + 1], b = simData.data[i + 2];
          const mean = (r + g + b) / 3;
          simData.data[i]     = Math.min(255, Math.max(0, mean + (r - mean) * 0.65));
          simData.data[i + 1] = Math.min(255, Math.max(0, mean + (g - mean) * 0.65));
          simData.data[i + 2] = Math.min(255, Math.max(0, mean + (b - mean) * 0.65));
        }
        sctx.putImageData(simData, 0, 0);

        // ── Window 3: Corrected — max-strength daltonization + double saturation pop
        const effStrength = 1.5;
        const effContrast = Math.min(1, p.contrast + mode.contrastBoost + 0.35);
        const effSat      = Math.min(1, p.saturation + mode.saturationBoost + 0.45);

        const corrData = new ImageData(new Uint8ClampedArray(orig.data), PROC_W, PROC_H);
        daltonizeInPlace(corrData.data, { type: p.type, severity: p.severity, strength: effStrength, contrast: effContrast, saturation: effSat });

        // Two-pass vivid saturation + contrast boost — makes hue shifts unmistakably obvious
        for (let i = 0; i < corrData.data.length; i += 4) {
          const r = corrData.data[i], g = corrData.data[i + 1], b = corrData.data[i + 2];
          const mean = (r + g + b) / 3;
          let nr = mean + (r - mean) * 1.6;
          let ng = mean + (g - mean) * 1.6;
          let nb = mean + (b - mean) * 1.6;
          nr = 128 + (nr - 128) * 1.2;
          ng = 128 + (ng - 128) * 1.2;
          nb = 128 + (nb - 128) * 1.2;
          corrData.data[i]     = Math.min(255, Math.max(0, nr));
          corrData.data[i + 1] = Math.min(255, Math.max(0, ng));
          corrData.data[i + 2] = Math.min(255, Math.max(0, nb));
        }
        cctx.putImageData(corrData, 0, 0);

        const [cr, cg, cb] = centerColor(corrData);
        setCenterName(nameColor(cr, cg, cb));

        if (p.voice && performance.now() - lastVoiceAt > 2500) {
          let phrase = `Center color is ${nameColor(cr, cg, cb)}`;
          const pri = detections.find((d) => mode.priorityClasses.includes(d.class));
          if (pri) phrase = `${pri.class.replace(/_/g, " ")} detected. ${phrase}.`;
          speak(phrase); lastVoiceAt = performance.now();
        }

        if (p.detect && detectorRef.current && performance.now() - lastDetectAt > 600) {
          lastDetectAt = performance.now();
          detectorRef.current.detect(oc).then((preds) => {
            const list = (preds as Array<{ class: string; score: number; bbox: number[] }>)
              .filter((d) => d.score > 0.5).slice(0, 6)
              .map((d) => ({ class: d.class, score: d.score, bbox: d.bbox as [number, number, number, number] }));
            setDetections(list); drawOverlay(list, mode.priorityClasses);
          }).catch(() => {});
        } else if (!p.detect) drawOverlay([], []);

        if (performance.now() - lastHistAt > 500) {
          lastHistAt = performance.now();
          setHists({ orig: histogram(orig), sim: histogram(simData), corr: histogram(corrData) });
        }

        frames++;
        const now = performance.now();
        if (now - lastFpsAt > 700) { setFps(Math.round((frames * 1000) / (now - lastFpsAt))); frames = 0; lastFpsAt = now; }
        setLatency(performance.now() - t0);
      } catch { /* ignore frame errors */ }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [streaming, profile, detections]);

  function drawOverlay(list: Array<{ class: string; bbox: [number, number, number, number] }>, priority: string[]) {
    const canvas = overlayRef.current; if (!canvas) return;
    canvas.width = PROC_W; canvas.height = PROC_H;
    const ctx = canvas.getContext("2d")!; ctx.clearRect(0, 0, PROC_W, PROC_H);
    for (const d of list) {
      const [x, y, w, h] = d.bbox;
      const isp = priority.includes(d.class);
      ctx.lineWidth = isp ? 3 : 2;
      ctx.strokeStyle = isp ? "rgb(255,80,80)" : "rgba(80,200,255,0.9)";
      ctx.shadowColor = isp ? "rgba(255,80,80,0.7)" : "transparent"; ctx.shadowBlur = isp ? 14 : 0;
      ctx.strokeRect(x, y, w, h); ctx.shadowBlur = 0;
      ctx.fillStyle = isp ? "rgba(255,80,80,0.95)" : "rgba(80,200,255,0.95)";
      ctx.font = "bold 12px Inter, sans-serif";
      const tw = ctx.measureText(d.class).width + 10;
      ctx.fillRect(x, Math.max(0, y - 18), tw, 18);
      ctx.fillStyle = "white"; ctx.fillText(d.class, x + 5, Math.max(12, y - 5));
    }
  }

  function update(patch: Partial<UserProfile>) {
    if (!profile) return;
    const next = { ...profile, ...patch }; setProfile(next); profileRef.current = next; saveProfile(next);
  }
  function changeStrength(v: number) {
    if (!profile) return; const delta = v - profile.strength; update({ strength: v }); recordStrengthChange(profileRef.current!, delta);
  }
  function changeMode(m: AccessibilityMode) {
    if (!profile) return; update({ mode: m }); recordModeUsage(profileRef.current!, m);
    if (profile.voice) speak(`${MODES[m].label} mode`);
  }
  function captureScreenshot() {
    const cc = corrCanvasRef.current; if (!cc) return;
    const a = document.createElement("a"); a.href = cc.toDataURL("image/png"); a.download = `colorease-${Date.now()}.png`; a.click();
  }

  if (!profile) return null;

  if (profile.type === "normal" && profile.sessions === 0) {
    return (
      <div className="grid min-h-dvh place-items-center px-6">
        <div className="glow-card rainbow-border max-w-md p-8 text-center">
          <h1 className="font-display text-2xl font-bold">No vision profile yet</h1>
          <p className="mt-2 text-muted-foreground">Take the quick Ishihara test to personalize correction.</p>
          <div className="mt-5 flex justify-center gap-3">
            <button onClick={() => navigate({ to: "/test" })} className="btn-rainbow">Take test</button>
            <Link to="/" className="btn-ghost-rainbow">Home</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh">
      <header className="mx-auto flex max-w-[1500px] items-center justify-between gap-4 px-6 py-4">
        <Logo />
        <div className="hidden items-center gap-2 md:flex">
          <span className="chip"><span className="live-dot" /> Live</span>
          <span className="chip">{fps} FPS</span>
          <span className="chip">{latency.toFixed(0)} ms / frame</span>
          <span className="chip">Center: {centerName}</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={captureScreenshot} className="btn-ghost-rainbow !py-2 !px-4 text-sm">Screenshot</button>
          <Link to="/test" className="text-sm text-muted-foreground hover:text-foreground">Retest</Link>
        </div>
      </header>

      {error && (
        <div className="mx-auto max-w-3xl rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">
          Camera error: {error}. Please grant camera permission and reload.
        </div>
      )}

      <main className="mx-auto grid max-w-[1500px] gap-6 px-6 pb-10 lg:grid-cols-12">

        {/* Three live panels */}
        <section className="lg:col-span-9 grid gap-4 md:grid-cols-3">
          <Panel label="Original Vision" subtitle="Raw camera feed" onMaximize={() => setMaximized("original")}>
            <canvas ref={origCanvasRef} className="h-full w-full" />
          </Panel>
          <Panel label="CVD Simulation" subtitle={`How ${displayType(profile.type)} sees`} onMaximize={() => setMaximized("simulated")}>
            <canvas ref={simCanvasRef} className="h-full w-full" />
          </Panel>
          <Panel label="Colour-Corrected" subtitle="Enhanced daltonization" onMaximize={() => setMaximized("corrected")}>
            <div className="relative h-full w-full">
              <canvas ref={corrCanvasRef} className="h-full w-full" />
              <canvas ref={overlayRef} className="pointer-events-none absolute inset-0 h-full w-full" />
            </div>
          </Panel>
        </section>

        {/* Sidebar */}
        <aside className="lg:col-span-3 space-y-4">
          <ProfileCard profile={profile} />
          <div className="glow-card p-5">
            <h3 className="font-display font-bold">Accessibility mode</h3>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {(Object.keys(MODES) as AccessibilityMode[]).map((m) => (
                <button key={m} onClick={() => changeMode(m)}
                  className={`rounded-xl border px-3 py-2 text-left text-xs transition ${profile.mode === m ? "border-transparent text-white" : "border-border bg-white hover:border-foreground/20"}`}
                  style={profile.mode === m ? { background: "var(--gradient-rainbow)", backgroundSize: "200% 100%" } : {}}>
                  <div className="font-semibold">{MODES[m].label}</div>
                  <div className={`mt-0.5 text-[10px] ${profile.mode === m ? "text-white/85" : "text-muted-foreground"}`}>{MODES[m].description}</div>
                </button>
              ))}
            </div>
          </div>
          <div className="glow-card p-5 space-y-4">
            <h3 className="font-display font-bold">Correction</h3>
            <Slider label="Strength" value={profile.strength} min={0} max={1.5} step={0.05} onChange={changeStrength} />
            <Slider label="Contrast" value={profile.contrast} min={0} max={1} step={0.05} onChange={(v) => update({ contrast: v })} />
            <Slider label="Saturation" value={profile.saturation} min={0} max={1} step={0.05} onChange={(v) => update({ saturation: v })} />
          </div>
          <div className="glow-card p-5 space-y-3">
            <h3 className="font-display font-bold">Assistance</h3>
            <Toggle label="Voice readout" checked={profile.voice} onChange={(v) => { update({ voice: v }); if (!v) stopSpeaking(); }} />
            <Toggle label="Smart object highlight" checked={profile.detect} onChange={(v) => update({ detect: v })} />
          </div>
          <CVDSimulatorCard origCanvasRef={origCanvasRef} />
        </aside>

        {/* Histograms */}
        <section className="lg:col-span-9 glow-card p-5">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold">Channel histograms</h3>
            <span className="text-xs text-muted-foreground">RGB · 32 bins · sampled</span>
          </div>
          <div className="mt-3 grid gap-4 md:grid-cols-3">
            <HistogramCanvas data={hists.orig} label="Original" />
            <HistogramCanvas data={hists.sim} label="Simulated" />
            <HistogramCanvas data={hists.corr} label="Corrected" />
          </div>
        </section>

        {/* Detections */}
        <section className="lg:col-span-3 glow-card p-5">
          <h3 className="font-display font-bold">Detections</h3>
          <p className="text-xs text-muted-foreground">{profile.detect ? "Live · COCO-SSD" : "Disabled"}</p>
          <ul className="mt-3 space-y-2 text-sm">
            {detections.length === 0 && <li className="text-muted-foreground">No objects detected.</li>}
            {detections.map((d, i) => {
              const isp = MODES[profile.mode].priorityClasses.includes(d.class);
              return (
                <li key={i} className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
                  <span className="font-medium">
                    {isp && <span className="mr-1.5 inline-block h-2 w-2 rounded-full" style={{ background: "var(--spec-red)" }} />}
                    {d.class}
                  </span>
                  <span className="text-xs text-muted-foreground">{Math.round(d.score * 100)}%</span>
                </li>
              );
            })}
          </ul>
        </section>

        <ImageAnalysisSection cvdType={profile.type} cvdSeverity={profile.severity} />
      </main>

      <video ref={videoRef} playsInline muted className="hidden" />

      {/* Maximize modals */}
      {maximized === "original" && (
        <MaximizeModal label="Original Vision" subtitle="Raw camera feed" srcCanvasRef={origCanvasRef} onClose={() => setMaximized(null)} />
      )}
      {maximized === "simulated" && (
        <MaximizeModal label="CVD Simulation" subtitle={`How ${displayType(profile.type)} sees`} srcCanvasRef={simCanvasRef} onClose={() => setMaximized(null)} />
      )}
      {maximized === "corrected" && (
        <MaximizeModal label="Colour-Corrected" subtitle="Enhanced daltonization" srcCanvasRef={corrCanvasRef} overlayCanvasRef={overlayRef} onClose={() => setMaximized(null)} />
      )}
    </div>
  );
}

// ─── shared sub-components ────────────────────────────────────────────────────

function Panel({ label, subtitle, children, onMaximize }: { label: string; subtitle: string; children: React.ReactNode; onMaximize: () => void }) {
  return (
    <div className="glow-card rainbow-border relative overflow-hidden p-1.5">
      <div className="panel-label flex items-center gap-2"><span className="live-dot" /> {label}</div>
      <div className="absolute right-3 top-3 z-10 flex items-center gap-1.5">
        <span className="rounded-full bg-white/85 px-2 py-0.5 text-[10px] text-muted-foreground backdrop-blur">{subtitle}</span>
        <button
          onClick={onMaximize}
          title={`Maximize ${label}`}
          className="rounded-full bg-white/85 hover:bg-white p-1 backdrop-blur transition shadow-sm"
          aria-label={`Maximize ${label}`}
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className="text-muted-foreground">
            <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
          </svg>
        </button>
      </div>
      <div className="aspect-[4/3] w-full overflow-hidden rounded-xl bg-black">{children}</div>
    </div>
  );
}

function ProfileCard({ profile }: { profile: UserProfile }) {
  return (
    <div className="glow-card rainbow-border p-5">
      <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Profile</div>
      <div className="mt-1 font-display text-lg font-bold">{displayType(profile.type)}</div>
      <div className="mt-1 text-xs text-muted-foreground">
        {profile.severityLabel} · {Math.round(profile.severity * 100)}% severity · {Math.round(profile.confidence * 100)}% confidence
      </div>
      <div className="mt-3 text-[11px] text-muted-foreground">Sessions: {profile.sessions} · Adaptive learning active</div>
    </div>
  );
}

function Slider({ label, value, min, max, step, onChange }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium">{label}</span>
        <span className="text-muted-foreground">{value.toFixed(2)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="ce-range mt-1.5 w-full accent-[color:var(--spec-blue)]" />
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-3">
      <span className="text-sm">{label}</span>
      <button type="button" onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 rounded-full transition ${checked ? "" : "bg-muted"}`}
        style={checked ? { background: "var(--gradient-rainbow)" } : {}} aria-pressed={checked}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? "left-[22px]" : "left-0.5"}`} />
      </button>
    </label>
  );
}

function displayType(t: string) {
  const map: Record<string, string> = { protan: "Protanopia", deutan: "Deuteranopia", tritan: "Tritanopia", normal: "Normal" };
  return map[t] ?? t;
}

// Advanced upgrade integration added.
// Uses stronger visible daltonization pipeline with alpha 2.8.
// Preserves original UI identity.
