import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";
import { loadProfile } from "@/lib/colorease/profile";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ColorEase — Adaptive AI Vision Enhancement for Color Blindness" },
      { name: "description", content: "Real-time adaptive recoloring and AI-assisted accessibility for color-blind users. Diagnose, simulate, and correct your vision live." },
      { property: "og:title", content: "ColorEase — Adaptive Vision Enhancement" },
      { property: "og:description", content: "Diagnose, simulate, and correct color blindness in real time with AI." },
    ],
  }),
  component: WelcomePage,
});

function WelcomePage() {
  const [hasProfile, setHasProfile] = useState(false);
  useEffect(() => { setHasProfile(!!loadProfile()); }, []);

  return (
    <div className="relative min-h-dvh">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <Logo />
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <a href="#how" className="hover:text-foreground transition">How it works</a>
          <a href="#features" className="hover:text-foreground transition">Features</a>
          <a href="#research" className="hover:text-foreground transition">Research</a>
        </nav>
      </header>

      <main className="mx-auto max-w-7xl px-6 pb-24">
        <section className="grid items-center gap-12 pt-10 lg:grid-cols-12">
          <div className="lg:col-span-7 animate-[fade-up_0.8s_both]">
            <div className="chip mb-5">
              <span className="live-dot" /> Real-time accessibility AI
            </div>
            <h1 className="font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
              See the world,
              <br />
              <span className="rainbow-text">in every color.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
              ColorEase diagnoses your color vision in minutes, simulates how you actually
              perceive the world, and intelligently recolors your live camera feed so
              confusing colors become unmistakably distinct.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link to="/test" className="btn-rainbow inline-flex items-center gap-2">
                Start vision test
                <span aria-hidden>→</span>
              </Link>
              {hasProfile && (
                <Link to="/dashboard" className="btn-ghost-rainbow inline-flex items-center gap-2">
                  Load existing profile
                </Link>
              )}
            </div>
            <div className="mt-8 flex flex-wrap gap-2 text-xs text-muted-foreground">
              <span className="chip">Protanopia</span>
              <span className="chip">Deuteranopia</span>
              <span className="chip">Tritanopia</span>
              <span className="chip">Adaptive daltonization</span>
              <span className="chip">Voice assist</span>
            </div>
          </div>

          <div className="lg:col-span-5">
            <SpectrumOrb />
          </div>
        </section>

        <section id="how" className="mt-28">
          <h2 className="font-display text-3xl font-bold md:text-4xl">How it works</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {[
              { n: "01", t: "Diagnose", d: "Take a quick digital Ishihara test. We detect type and severity with confidence scoring." },
              { n: "02", t: "Simulate", d: "See exactly how a person with your deficiency perceives the world, in real time." },
              { n: "03", t: "Correct", d: "Adaptive daltonization recolors your camera feed so confusing hues become distinguishable." },
            ].map((s) => (
              <div key={s.n} className="glow-card rainbow-border relative p-6">
                <div className="text-xs font-semibold tracking-widest text-muted-foreground">{s.n}</div>
                <h3 className="mt-2 font-display text-xl font-bold">{s.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="features" className="mt-24">
          <h2 className="font-display text-3xl font-bold md:text-4xl">Built for the real world</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[
              ["Traffic mode", "Boosts red & green for signals and warnings."],
              ["Classroom mode", "Sharpens charts, slides and educational content."],
              ["Medical mode", "Highlights subtle tints in indicators and labels."],
              ["Map reading", "Separates regions encoded only by color."],
              ["Voice assistance", "Speaks detected colors and hazards aloud."],
              ["Adaptive learning", "Remembers and personalizes your preferences."],
            ].map(([t, d]) => (
              <div key={t} className="glow-card p-5">
                <h3 className="font-semibold">{t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="research" className="mt-24">
          <div className="glow-card rainbow-border p-8 md:p-10">
            <div className="grid items-center gap-8 md:grid-cols-2">
              <div>
                <h2 className="font-display text-3xl font-bold">Research-grade evaluation</h2>
                <p className="mt-3 text-muted-foreground">
                  Live FPS, processing latency, color-distance improvement, and recognition
                  accuracy gain — measured per session and visualized with histograms.
                </p>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                {[["FPS","Real-time"],["ΔE","Color gain"],["Acc.","Recognition"]].map(([a,b]) => (
                  <div key={a} className="rounded-2xl border border-border bg-white/60 p-4">
                    <div className="rainbow-text font-display text-2xl font-bold">{a}</div>
                    <div className="text-xs text-muted-foreground">{b}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="mx-auto max-w-7xl px-6 py-10 text-center text-xs text-muted-foreground">
        ColorEase · Adaptive AI-Based Vision Enhancement System
      </footer>
    </div>
  );
}

function SpectrumOrb() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-md animate-[float-slow_6s_ease-in-out_infinite]">
      <div
        className="absolute inset-0 rounded-full blur-3xl opacity-70"
        style={{ background: "var(--gradient-rainbow-soft)" }}
      />
      <div
        className="absolute inset-6 rounded-full"
        style={{
          background: "conic-gradient(from 90deg, var(--spec-red), var(--spec-orange), var(--spec-yellow), var(--spec-green), var(--spec-blue), var(--spec-indigo), var(--spec-violet), var(--spec-red))",
          filter: "saturate(1.1)",
        }}
      />
      <div className="absolute inset-12 rounded-full bg-white/85 backdrop-blur" />
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">spectrum</div>
          <div className="mt-1 font-display text-3xl font-bold">7 colors,</div>
          <div className="rainbow-text font-display text-3xl font-bold">one vision.</div>
        </div>
      </div>
    </div>
  );
}
