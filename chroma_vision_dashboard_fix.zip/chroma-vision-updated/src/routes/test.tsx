import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Logo } from "@/components/Logo";
import { PlateCanvas } from "@/components/PlateCanvas";
import { PLATES, diagnose, type PlateAnswer } from "@/lib/colorease/ishihara";
import { defaultProfile, loadProfile, saveProfile } from "@/lib/colorease/profile";

export const Route = createFileRoute("/test")({
  head: () => ({
    meta: [
      { title: "Vision Test — ColorEase" },
      { name: "description", content: "Take a digital Ishihara color vision test. Detects protanopia, deuteranopia, and tritanopia with severity and confidence scoring." },
      { property: "og:title", content: "Digital Ishihara Vision Test — ColorEase" },
      { property: "og:description", content: "Diagnose your color vision deficiency type and severity in minutes." },
    ],
  }),
  component: TestPage,
});

type Phase = "intro" | "test" | "result";

function TestPage() {
  const [phase, setPhase] = useState<Phase>("intro");
  const [idx, setIdx] = useState(0);
  const [input, setInput] = useState("");
  const [answers, setAnswers] = useState<PlateAnswer[]>([]);
  const navigate = useNavigate();

  const plate = PLATES[idx];
  const progress = ((idx) / PLATES.length) * 100;
  const result = useMemo(() => (phase === "result" ? diagnose(answers) : null), [phase, answers]);

  function submit() {
    const a: PlateAnswer = { plateId: plate.id, answer: input };
    const next = [...answers, a];
    setAnswers(next);
    setInput("");
    if (idx + 1 >= PLATES.length) setPhase("result");
    else setIdx(idx + 1);
  }
  function skip() { submit(); }

  function saveAndContinue() {
    if (!result) return;
    const existing = loadProfile() ?? defaultProfile();
    const profile = {
      ...existing,
      type: result.type,
      severity: result.severity,
      severityLabel: result.severityLabel,
      confidence: result.confidence,
      strength: Math.max(0.3, result.recommendedStrength),
      sessions: existing.sessions + 1,
      updatedAt: Date.now(),
    };
    saveProfile(profile);
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="min-h-dvh">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <Logo />
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Back home</Link>
      </header>

      <main className="mx-auto max-w-3xl px-6 pb-20">
        {phase === "intro" && (
          <section className="animate-[fade-up_0.5s_both] glow-card rainbow-border p-8 md:p-12 text-center">
            <h1 className="font-display text-3xl font-bold md:text-4xl">Digital Ishihara Test</h1>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              You'll see a series of dotted plates. Type the number you can see, or leave it blank
              if nothing is visible. Trust your first impression — the test takes about a minute.
            </p>
            <ul className="mx-auto mt-6 grid max-w-md gap-2 text-left text-sm text-muted-foreground">
              <li>• {PLATES.length} plates total</li>
              <li>• View on a well-lit screen, at arm's length</li>
              <li>• Don't squint or strain — answer naturally</li>
            </ul>
            <button onClick={() => setPhase("test")} className="btn-rainbow mt-8 inline-flex">
              Begin test →
            </button>
          </section>
        )}

        {phase === "test" && plate && (
          <section className="animate-[fade-up_0.5s_both]">
            <div className="mb-6 flex items-center justify-between text-sm text-muted-foreground">
              <span>Plate {idx + 1} of {PLATES.length}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="mb-6 h-1.5 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full transition-all"
                style={{ width: `${((idx + 1) / PLATES.length) * 100}%`, background: "var(--gradient-rainbow)" }}
              />
            </div>
            <div className="glow-card rainbow-border p-8 text-center">
              <div className="flex justify-center">
                <PlateCanvas plate={plate} size={340} />
              </div>
              <p className="mt-6 text-sm text-muted-foreground">What number do you see?</p>
              <form
                onSubmit={(e) => { e.preventDefault(); submit(); }}
                className="mx-auto mt-4 flex max-w-sm items-center gap-2"
              >
                <input
                  autoFocus
                  inputMode="numeric"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type a number, or leave blank"
                  className="flex-1 rounded-full border border-border bg-white px-5 py-3 text-center text-lg outline-none ring-0 transition focus:border-transparent focus:ring-2 focus:ring-[color:var(--spec-blue)]"
                />
                <button type="submit" className="btn-rainbow !py-3">Next</button>
              </form>
              <button onClick={skip} className="mt-3 text-xs text-muted-foreground hover:text-foreground">
                I can't see anything — skip
              </button>
            </div>
          </section>
        )}

        {phase === "result" && result && (
          <section className="animate-[fade-up_0.5s_both]">
            <div className="glow-card rainbow-border p-8 md:p-10">
              <div className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Diagnosis</div>
              <h1 className="mt-1 font-display text-4xl font-bold">
                {result.type === "normal"
                  ? "Normal trichromatic vision"
                  : `${displayType(result.type)} · ${result.severityLabel}`}
              </h1>
              <p className="mt-3 text-muted-foreground">
                {result.type === "normal"
                  ? "We didn't detect a significant color vision deficiency. You can still explore the simulator and correction tools."
                  : "Your personalized vision profile is ready. ColorEase will recolor your camera feed adaptively in real time."}
              </p>

              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                <Stat label="Severity" value={`${Math.round(result.severity * 100)}%`} />
                <Stat label="Confidence" value={`${Math.round(result.confidence * 100)}%`} />
                <Stat label="Recommended strength" value={result.recommendedStrength.toFixed(2)} />
              </div>

              <details className="mt-6 rounded-2xl border border-border p-4 text-sm text-muted-foreground">
                <summary className="cursor-pointer font-medium text-foreground">Per-type evidence</summary>
                <div className="mt-3 grid gap-2 sm:grid-cols-3">
                  {(Object.entries(result.scores) as Array<[string, number]>).map(([k, v]) => (
                    <div key={k} className="rounded-lg bg-muted/60 p-3 text-center">
                      <div className="text-xs uppercase tracking-wider">{displayType(k)}</div>
                      <div className="font-display text-lg font-bold text-foreground">{v.toFixed(1)}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-3">Errors: {result.errors} / {result.totalRelevant}</div>
              </details>

              <div className="mt-8 flex flex-wrap gap-3">
                <button onClick={saveAndContinue} className="btn-rainbow inline-flex">
                  Save profile & launch dashboard →
                </button>
                <button
                  onClick={() => { setPhase("intro"); setIdx(0); setAnswers([]); }}
                  className="btn-ghost-rainbow inline-flex"
                >
                  Retake test
                </button>
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-white p-4 text-center">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 rainbow-text font-display text-2xl font-bold">{value}</div>
    </div>
  );
}

function displayType(t: string) {
  const map: Record<string, string> = { protan: "Protanopia", deutan: "Deuteranopia", tritan: "Tritanopia", normal: "Normal" };
  return map[t] ?? t;
}
