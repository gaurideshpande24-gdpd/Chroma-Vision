// Lightweight Web Speech API wrapper with throttling so we don't spam.
let lastSpoken = "";
let lastAt = 0;

export function speak(text: string, minGapMs = 1800) {
  if (typeof window === "undefined") return;
  const synth = window.speechSynthesis;
  if (!synth) return;
  const now = Date.now();
  if (text === lastSpoken && now - lastAt < minGapMs) return;
  lastSpoken = text; lastAt = now;
  try {
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.0; u.pitch = 1.0; u.volume = 1.0;
    synth.speak(u);
  } catch { /* noop */ }
}

export function stopSpeaking() {
  if (typeof window !== "undefined" && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
}
