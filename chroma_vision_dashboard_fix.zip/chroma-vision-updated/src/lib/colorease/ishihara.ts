// Ishihara-style plate definitions and adaptive scoring.
// Plates are rendered procedurally as colored dot fields (see PlateCanvas).
// Each plate defines:
//   - the digit a normal trichromat sees
//   - what each deficiency type typically reports (or null = sees nothing)
//   - the confusion-line color pair for foreground / background

import type { Deficiency } from "./simulation";

export interface PlateDef {
  id: number;
  digit: string;                                    // what normal vision sees
  altSee: Partial<Record<Deficiency, string | null>>; // what deficient eyes typically report
  fg: [number, number, number];                     // figure dot color (sRGB)
  bg: [number, number, number];                     // background dot color
  targets: Array<"protan" | "deutan" | "tritan">;   // which types this plate diagnoses
}

// 9 plates covering red-green (protan/deutan) confusion lines and tritan blue-yellow.
export const PLATES: PlateDef[] = [
  // Demo / control plate (everyone sees 12)
  { id: 1, digit: "12", altSee: { protan: "12", deutan: "12", tritan: "12" }, fg: [220, 90, 80], bg: [200, 180, 120], targets: [] },
  // Red-green: figure visible only to normals
  { id: 2, digit: "8",  altSee: { protan: "3", deutan: "3", tritan: "8" },     fg: [200, 80, 60],  bg: [150, 140, 80], targets: ["protan", "deutan"] },
  { id: 3, digit: "29", altSee: { protan: "70", deutan: "70", tritan: "29" },  fg: [180, 70, 60],  bg: [130, 150, 90], targets: ["protan", "deutan"] },
  { id: 4, digit: "5",  altSee: { protan: "2", deutan: "2", tritan: "5" },     fg: [110, 160, 80], bg: [200, 130, 80], targets: ["protan", "deutan"] },
  { id: 5, digit: "3",  altSee: { protan: "5", deutan: "5", tritan: "3" },     fg: [100, 150, 70], bg: [190, 110, 70], targets: ["protan", "deutan"] },
  // Protan-specific (deutan should still see roughly 26 differently than protan)
  { id: 6, digit: "26", altSee: { protan: "6",  deutan: "2",  tritan: "26" },  fg: [200, 60, 60],  bg: [120, 140, 80], targets: ["protan"] },
  { id: 7, digit: "42", altSee: { protan: "4",  deutan: "2",  tritan: "42" },  fg: [180, 50, 60],  bg: [130, 160, 90], targets: ["protan"] },
  // Tritan: blue-yellow confusion
  { id: 8, digit: "7",  altSee: { protan: "7",  deutan: "7",  tritan: null },  fg: [70, 130, 200], bg: [200, 200, 110], targets: ["tritan"] },
  { id: 9, digit: "45", altSee: { protan: "45", deutan: "45", tritan: null },  fg: [80, 140, 210], bg: [210, 200, 120], targets: ["tritan"] },
];

export interface PlateAnswer { plateId: number; answer: string; }

export interface Diagnosis {
  type: Deficiency;
  severity: number;          // 0..1
  severityLabel: "Mild" | "Moderate" | "Severe" | "None";
  confidence: number;        // 0..1
  recommendedStrength: number; // 0..1.5
  scores: Record<"protan" | "deutan" | "tritan", number>;
  totalRelevant: number;
  errors: number;
}

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, "");

export function diagnose(answers: PlateAnswer[]): Diagnosis {
  const scores = { protan: 0, deutan: 0, tritan: 0 };
  const counts = { protan: 0, deutan: 0, tritan: 0 };
  let errors = 0;
  let totalRelevant = 0;

  for (const a of answers) {
    const plate = PLATES.find((p) => p.id === a.plateId);
    if (!plate || plate.targets.length === 0) continue;
    const user = norm(a.answer);
    const normalAns = norm(plate.digit);
    const matchedNormal = user === normalAns;

    for (const t of plate.targets) {
      counts[t]++;
      totalRelevant++;
      const expected = plate.altSee[t];
      const expectedNorm = expected == null ? "" : norm(expected);

      if (matchedNormal) {
        // user sees what a normal sees → -1 evidence for this deficiency
        scores[t] -= 1;
      } else if (expected === null && user === "") {
        // expected to see nothing and user said nothing → strong +
        scores[t] += 2; errors++;
      } else if (user === expectedNorm && expectedNorm !== "") {
        // matched the deficient response pattern → strong +
        scores[t] += 2; errors++;
      } else {
        // any other mismatch with the normal answer → weak +
        scores[t] += 0.6; errors++;
      }
    }
  }

  // pick winning type
  const ranked = (Object.entries(scores) as Array<[keyof typeof scores, number]>)
    .sort((a, b) => b[1] - a[1]);
  const [topType, topScore] = ranked[0];
  const secondScore = ranked[1][1];

  const maxPossible = Math.max(1, counts[topType] * 2);
  const ratio = Math.max(0, topScore) / maxPossible; // 0..1
  // separation between top and runner-up boosts confidence
  const separation = Math.max(0, topScore - secondScore) / maxPossible;
  const confidence = Math.min(1, 0.5 * ratio + 0.5 * separation + 0.1);

  let type: Deficiency = "normal";
  let severity = 0;
  let label: Diagnosis["severityLabel"] = "None";

  if (topScore > 0.5 && ratio > 0.15) {
    type = topType;
    severity = Math.min(1, ratio);
    label = severity < 0.34 ? "Mild" : severity < 0.7 ? "Moderate" : "Severe";
  }

  const recommendedStrength = type === "normal" ? 0 : 0.5 + severity * 0.8;

  return {
    type, severity, severityLabel: label,
    confidence, recommendedStrength,
    scores, totalRelevant, errors,
  };
}
