// Compute a 32-bin per-channel RGB histogram.
export interface Histogram { r: number[]; g: number[]; b: number[]; bins: number; }

export function histogram(img: ImageData, bins = 32): Histogram {
  const r = new Array(bins).fill(0);
  const g = new Array(bins).fill(0);
  const b = new Array(bins).fill(0);
  const d = img.data;
  const step = 4 * 4; // sample every 4 pixels for speed
  const scale = bins / 256;
  for (let i = 0; i < d.length; i += step) {
    r[Math.min(bins - 1, Math.floor(d[i] * scale))]++;
    g[Math.min(bins - 1, Math.floor(d[i + 1] * scale))]++;
    b[Math.min(bins - 1, Math.floor(d[i + 2] * scale))]++;
  }
  return { r, g, b, bins };
}
