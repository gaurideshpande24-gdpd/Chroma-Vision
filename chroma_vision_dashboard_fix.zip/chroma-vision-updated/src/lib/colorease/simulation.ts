// Color-blindness simulation matrices (Brettel/Vienot/Machado approximations).
// Applied in linear sRGB space. Severity in [0,1] mixes between identity and full.

export type Deficiency = "protan" | "deutan" | "tritan" | "normal";

// Full-strength matrices (sRGB approximations from Machado et al. 2009)
const M_FULL: Record<Exclude<Deficiency, "normal">, number[]> = {
  protan: [0.152286, 1.052583, -0.204868, 0.114503, 0.786281, 0.099216, -0.003882, -0.048116, 1.051998],
  deutan: [0.367322, 0.860646, -0.227968, 0.280085, 0.672501, 0.047413, -0.011820, 0.042940, 0.968881],
  tritan: [1.255528, -0.076749, -0.178779, -0.078411, 0.930809, 0.147602, 0.004733, 0.691367, 0.303900],
};

const IDENTITY = [1, 0, 0, 0, 1, 0, 0, 0, 1];

export function getSimMatrix(type: Deficiency, severity: number): number[] {
  if (type === "normal" || severity <= 0) return IDENTITY;
  const s = Math.min(1, Math.max(0, severity));
  const m = M_FULL[type];
  return m.map((v, i) => IDENTITY[i] * (1 - s) + v * s);
}

// Apply a 3x3 matrix to RGBA image data in-place (clamped 0..255)
export function applyMatrixInPlace(data: Uint8ClampedArray, m: number[]) {
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const nr = m[0] * r + m[1] * g + m[2] * b;
    const ng = m[3] * r + m[4] * g + m[5] * b;
    const nb = m[6] * r + m[7] * g + m[8] * b;
    data[i] = nr < 0 ? 0 : nr > 255 ? 255 : nr;
    data[i + 1] = ng < 0 ? 0 : ng > 255 ? 255 : ng;
    data[i + 2] = nb < 0 ? 0 : nb > 255 ? 255 : nb;
  }
}
