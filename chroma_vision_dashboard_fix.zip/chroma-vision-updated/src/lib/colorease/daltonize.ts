// Adaptive daltonization: simulate the user's perception, compute the
// per-pixel color error, then redistribute that error across remaining
// channels so confusing colors become distinguishable.
//
// Pipeline (per pixel):
//   sim   = M_sim · rgb
//   err   = rgb - sim
//   shift = E · err          (channel redistribution matrix per type)
//   out   = clamp(rgb + strength * shift)
// Optional: contrast & saturation boost in HSV space.

import { getSimMatrix, applyMatrixInPlace, type Deficiency } from "./simulation";

// Channel redistribution matrices (classic daltonization, per type)
const E: Record<Exclude<Deficiency, "normal">, number[]> = {
  // Protanopia: push lost red into G & B
  protan: [0, 0, 0, 0.7, 1, 0, 0.7, 0, 1],
  // Deuteranopia: push lost green into R & B
  deutan: [1, 0.7, 0, 0, 0, 0, 0, 0.7, 1],
  // Tritanopia: push lost blue into R & G
  tritan: [1, 0, 0.7, 0, 1, 0.7, 0, 0, 0],
};

export interface CorrectionOptions {
  type: Deficiency;
  severity: number;          // 0..1, from diagnosis
  strength: number;          // 0..1.5 user multiplier
  contrast: number;          // 0..1 boost
  saturation: number;        // 0..1 boost
}

export function daltonizeInPlace(data: Uint8ClampedArray, opts: CorrectionOptions) {
  if (opts.type === "normal") return;
  const sim = getSimMatrix(opts.type, opts.severity);
  const e = E[opts.type];
  const k = opts.strength;
  const cBoost = 1 + opts.contrast * 0.6;
  const sBoost = 1 + opts.saturation * 0.7;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    // simulated
    const sr = sim[0] * r + sim[1] * g + sim[2] * b;
    const sg = sim[3] * r + sim[4] * g + sim[5] * b;
    const sb = sim[6] * r + sim[7] * g + sim[8] * b;
    // error
    const er = r - sr, eg = g - sg, eb = b - sb;
    // shifted error
    const shr = e[0] * er + e[1] * eg + e[2] * eb;
    const shg = e[3] * er + e[4] * eg + e[5] * eb;
    const shb = e[6] * er + e[7] * eg + e[8] * eb;
    let nr = r + k * shr;
    let ng = g + k * shg;
    let nb = b + k * shb;

    // Saturation + contrast boost (cheap HSL-ish around mean)
    const mean = (nr + ng + nb) / 3;
    nr = mean + (nr - mean) * sBoost;
    ng = mean + (ng - mean) * sBoost;
    nb = mean + (nb - mean) * sBoost;
    nr = 128 + (nr - 128) * cBoost;
    ng = 128 + (ng - 128) * cBoost;
    nb = 128 + (nb - 128) * cBoost;

    data[i] = nr < 0 ? 0 : nr > 255 ? 255 : nr;
    data[i + 1] = ng < 0 ? 0 : ng > 255 ? 255 : ng;
    data[i + 2] = nb < 0 ? 0 : nb > 255 ? 255 : nb;
  }
}

export function simulateInPlace(data: Uint8ClampedArray, type: Deficiency, severity: number) {
  if (type === "normal") return;
  applyMatrixInPlace(data, getSimMatrix(type, severity));
}
