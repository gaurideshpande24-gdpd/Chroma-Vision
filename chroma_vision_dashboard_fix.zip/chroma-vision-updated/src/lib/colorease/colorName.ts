// Map an RGB triplet to a basic color name (used by voice + center-readout).
const NAMES: Array<{ name: string; rgb: [number, number, number] }> = [
  { name: "red",     rgb: [220, 30, 30] },
  { name: "orange",  rgb: [240, 140, 30] },
  { name: "yellow",  rgb: [240, 220, 60] },
  { name: "green",   rgb: [40, 180, 60] },
  { name: "cyan",    rgb: [40, 200, 220] },
  { name: "blue",    rgb: [40, 80, 220] },
  { name: "indigo",  rgb: [70, 50, 160] },
  { name: "violet",  rgb: [160, 60, 200] },
  { name: "pink",    rgb: [240, 130, 180] },
  { name: "brown",   rgb: [120, 70, 40] },
  { name: "white",   rgb: [240, 240, 240] },
  { name: "gray",    rgb: [130, 130, 130] },
  { name: "black",   rgb: [20, 20, 20] },
];

export function nameColor(r: number, g: number, b: number): string {
  let best = NAMES[0]; let bestD = Infinity;
  for (const c of NAMES) {
    const dr = r - c.rgb[0], dg = g - c.rgb[1], db = b - c.rgb[2];
    const d = dr * dr + dg * dg + db * db;
    if (d < bestD) { bestD = d; best = c; }
  }
  return best.name;
}

// Sample average color in a small box around the center of an ImageData.
export function centerColor(img: ImageData, boxFrac = 0.08): [number, number, number] {
  const { width, height, data } = img;
  const bw = Math.max(2, Math.floor(width * boxFrac));
  const bh = Math.max(2, Math.floor(height * boxFrac));
  const x0 = Math.floor((width - bw) / 2);
  const y0 = Math.floor((height - bh) / 2);
  let r = 0, g = 0, b = 0, n = 0;
  for (let y = y0; y < y0 + bh; y++) {
    let i = (y * width + x0) * 4;
    for (let x = 0; x < bw; x++) {
      r += data[i]; g += data[i + 1]; b += data[i + 2];
      i += 4; n++;
    }
  }
  return [r / n, g / n, b / n];
}
