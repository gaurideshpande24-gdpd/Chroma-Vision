
export const CVD_MATRICES = {
  protanopia: [
    [0.567, 0.433, 0],
    [0.558, 0.442, 0],
    [0, 0, 1],
  ],
  deuteranopia: [
    [0.625, 0.375, 0],
    [0.7, 0.3, 0],
    [0, 0, 1],
  ],
  tritanopia: [
    [1, 0, 0],
    [0, 0.433, 0.567],
    [0, 0.475, 0.525],
  ],
};

export const CORRECTION_MATRIX = [
  [0, 0, 0],
  [0.8, 1.0, 0],
  [0.8, 0, 1.0],
];

export function enhancedDaltonize(
  data: Uint8ClampedArray,
  mode: keyof typeof CVD_MATRICES,
  alpha = 2.8
) {
  const out = new Uint8ClampedArray(data.length);
  const matrix = CVD_MATRICES[mode];

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const sr =
      r * matrix[0][0] +
      g * matrix[0][1] +
      b * matrix[0][2];

    const sg =
      r * matrix[1][0] +
      g * matrix[1][1] +
      b * matrix[1][2];

    const sb =
      r * matrix[2][0] +
      g * matrix[2][1] +
      b * matrix[2][2];

    const er = r - sr;
    const eg = g - sg;
    const eb = b - sb;

    const cr =
      er * CORRECTION_MATRIX[0][0] +
      eg * CORRECTION_MATRIX[0][1] +
      eb * CORRECTION_MATRIX[0][2];

    const cg =
      er * CORRECTION_MATRIX[1][0] +
      eg * CORRECTION_MATRIX[1][1] +
      eb * CORRECTION_MATRIX[1][2];

    const cb =
      er * CORRECTION_MATRIX[2][0] +
      eg * CORRECTION_MATRIX[2][1] +
      eb * CORRECTION_MATRIX[2][2];

    out[i] = Math.min(255, r + alpha * cr);
    out[i + 1] = Math.min(255, g + alpha * cg);
    out[i + 2] = Math.min(255, b + alpha * cb);
    out[i + 3] = 255;
  }

  return out;
}

export function simpleFFTLabel() {
  return {
    lowFrequency: "Center Region",
    highFrequency: "Outer Region",
  };
}
