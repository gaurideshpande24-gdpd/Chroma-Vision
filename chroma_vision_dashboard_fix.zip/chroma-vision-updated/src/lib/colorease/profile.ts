import type { Deficiency } from "./simulation";

export type AccessibilityMode =
  | "general" | "traffic" | "classroom" | "medical" | "gaming" | "map" | "highContrast";

export interface UserProfile {
  createdAt: number;
  updatedAt: number;
  type: Deficiency;
  severity: number;
  severityLabel: string;
  confidence: number;
  strength: number;
  contrast: number;
  saturation: number;
  mode: AccessibilityMode;
  voice: boolean;
  detect: boolean;
  sessions: number;
  // adaptive learning: rolling adjustments
  adaptive: {
    strengthDeltas: number[];
    modeUsage: Record<AccessibilityMode, number>;
  };
}

const KEY = "colorease.profile.v1";

export function defaultProfile(): UserProfile {
  return {
    createdAt: Date.now(), updatedAt: Date.now(),
    type: "normal", severity: 0, severityLabel: "None",
    confidence: 0, strength: 0.8, contrast: 0.2, saturation: 0.25,
    mode: "general", voice: false, detect: false, sessions: 0,
    adaptive: { strengthDeltas: [], modeUsage: {
      general: 0, traffic: 0, classroom: 0, medical: 0,
      gaming: 0, map: 0, highContrast: 0,
    }},
  };
}

export function loadProfile(): UserProfile | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw) as UserProfile;
  } catch { return null; }
}

export function saveProfile(p: UserProfile) {
  if (typeof window === "undefined") return;
  p.updatedAt = Date.now();
  localStorage.setItem(KEY, JSON.stringify(p));
}

export function recordStrengthChange(p: UserProfile, delta: number) {
  p.adaptive.strengthDeltas.push(delta);
  if (p.adaptive.strengthDeltas.length > 30) p.adaptive.strengthDeltas.shift();
  saveProfile(p);
}

export function recordModeUsage(p: UserProfile, mode: AccessibilityMode) {
  p.adaptive.modeUsage[mode] = (p.adaptive.modeUsage[mode] || 0) + 1;
  saveProfile(p);
}

export function suggestedStrength(p: UserProfile): number {
  const d = p.adaptive.strengthDeltas;
  if (d.length < 3) return p.strength;
  const avg = d.reduce((a, b) => a + b, 0) / d.length;
  return Math.max(0, Math.min(1.5, p.strength + avg * 0.4));
}
