import type { AccessibilityMode } from "./profile";

export interface ModeConfig {
  label: string;
  description: string;
  strengthMul: number;
  contrastBoost: number;
  saturationBoost: number;
  // priority labels for object detection / voice
  priorityClasses: string[];
}

export const MODES: Record<AccessibilityMode, ModeConfig> = {
  general:      { label: "General",       description: "Balanced everyday correction.",         strengthMul: 1.0, contrastBoost: 0.0, saturationBoost: 0.0, priorityClasses: [] },
  traffic:      { label: "Traffic",       description: "Boosts reds & greens for signals.",     strengthMul: 1.25, contrastBoost: 0.15, saturationBoost: 0.2, priorityClasses: ["traffic light", "stop sign", "car", "truck", "person"] },
  classroom:    { label: "Classroom",     description: "Sharpens charts, slides, diagrams.",    strengthMul: 1.1, contrastBoost: 0.25, saturationBoost: 0.1, priorityClasses: ["book", "tv", "laptop"] },
  medical:      { label: "Medical",       description: "Highlights tints & subtle hue shifts.", strengthMul: 1.15, contrastBoost: 0.2, saturationBoost: 0.3, priorityClasses: ["bottle", "cup"] },
  gaming:       { label: "Gaming",        description: "Snappy, vivid recoloring.",             strengthMul: 1.2, contrastBoost: 0.1, saturationBoost: 0.4, priorityClasses: [] },
  map:          { label: "Map Reading",   description: "Separates region color codes.",         strengthMul: 1.3, contrastBoost: 0.3, saturationBoost: 0.25, priorityClasses: [] },
  highContrast: { label: "High Contrast", description: "Maximum legibility, less natural look.", strengthMul: 1.4, contrastBoost: 0.5, saturationBoost: 0.45, priorityClasses: [] },
};
