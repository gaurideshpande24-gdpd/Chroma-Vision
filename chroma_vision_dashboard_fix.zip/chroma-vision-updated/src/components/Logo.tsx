import { Link } from "@tanstack/react-router";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2 ${className}`} aria-label="ColorEase home">
      <span
        aria-hidden
        className="inline-block h-8 w-8 rounded-xl"
        style={{
          background: "var(--gradient-rainbow)",
          boxShadow: "0 6px 18px -6px color-mix(in oklab, var(--spec-violet) 50%, transparent)",
        }}
      />
      <span className="font-display text-lg font-bold tracking-tight">
        Color<span className="rainbow-text">Ease</span>
      </span>
    </Link>
  );
}
