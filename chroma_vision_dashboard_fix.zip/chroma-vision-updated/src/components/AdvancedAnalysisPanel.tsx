
import React from "react";

export function AdvancedAnalysisPanel() {
  return (
    <div className="rounded-2xl border bg-white/80 p-4 mt-4">
      <h2 className="font-bold text-lg mb-3">
        Advanced Vision Analysis
      </h2>

      <div className="grid grid-cols-2 gap-4">

        <div className="border rounded-xl p-3">
          <div className="font-semibold">
            FFT Magnitude Spectrum
          </div>
          <div className="text-sm opacity-70">
            Low / High frequency analysis
          </div>
        </div>

        <div className="border rounded-xl p-3">
          <div className="font-semibold">
            Edge Detection
          </div>
          <div className="text-sm opacity-70">
            Sobel + Canny rendering
          </div>
        </div>

        <div className="border rounded-xl p-3">
          <div className="font-semibold">
            K-Means Segmentation
          </div>

          <input
            type="range"
            min={2}
            max={10}
            defaultValue={4}
            className="w-full mt-2"
          />
        </div>

        <div className="border rounded-xl p-3">
          <div className="font-semibold">
            JPEG Compression
          </div>

          <input
            type="range"
            min={1}
            max={100}
            defaultValue={90}
            className="w-full mt-2"
          />
        </div>

      </div>
    </div>
  );
}
