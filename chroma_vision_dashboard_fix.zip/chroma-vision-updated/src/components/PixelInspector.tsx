
import React from "react";

interface PixelInspectorProps {
  x: number;
  y: number;
  rgb: number[];
  hsv: number[];
  lab: number[];
}

export function PixelInspector(props: PixelInspectorProps) {
  return (
    <div className="absolute right-4 bottom-4 bg-black/70 text-white rounded-xl p-3 text-xs z-50">
      <div>Pixel Inspector</div>
      <div>X: {props.x}</div>
      <div>Y: {props.y}</div>
      <div>RGB: {props.rgb.join(", ")}</div>
      <div>HSV: {props.hsv.join(", ")}</div>
      <div>LAB: {props.lab.join(", ")}</div>
    </div>
  );
}
