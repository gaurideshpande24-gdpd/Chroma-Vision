// PlateCanvas: procedurally renders an Ishihara-style colored-dot plate.
// A mask digit is drawn off-screen; foreground dots fall within the digit
// pixels, background dots fill the rest. Color jitter mimics real plates.
import { useEffect, useRef } from "react";
import type { PlateDef } from "@/lib/colorease/ishihara";

interface Props { plate: PlateDef; size?: number; }

function jitter(c: number, amt = 22) {
  return Math.max(0, Math.min(255, c + (Math.random() - 0.5) * amt * 2));
}

export function PlateCanvas({ plate, size = 320 }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    const W = size, H = size;
    canvas.width = W; canvas.height = H;
    ctx.clearRect(0, 0, W, H);

    // Mask layer: draw the digit, read pixels to know foreground regions.
    const mask = document.createElement("canvas");
    mask.width = W; mask.height = H;
    const mctx = mask.getContext("2d")!;
    mctx.fillStyle = "white";
    mctx.fillRect(0, 0, W, H);
    mctx.fillStyle = "black";
    mctx.font = `bold ${Math.floor(H * 0.62)}px "Space Grotesk", sans-serif`;
    mctx.textAlign = "center"; mctx.textBaseline = "middle";
    mctx.fillText(plate.digit, W / 2, H / 2 + H * 0.02);
    const maskData = mctx.getImageData(0, 0, W, H).data;

    // Clip everything to a circle.
    ctx.save();
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, W / 2 - 4, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    // Subtle background tint
    ctx.fillStyle = `rgb(${plate.bg.map((c) => Math.round(c * 0.6 + 255 * 0.4)).join(",")})`;
    ctx.fillRect(0, 0, W, H);

    // Scatter dots
    const radius = W / 2 - 6;
    const cx = W / 2, cy = H / 2;
    const minR = 3, maxR = 8;
    const tries = Math.floor(W * H * 0.06);
    const placed: Array<{ x: number; y: number; r: number }> = [];
    for (let i = 0; i < tries; i++) {
      const a = Math.random() * Math.PI * 2;
      const rr = Math.sqrt(Math.random()) * radius;
      const x = cx + Math.cos(a) * rr;
      const y = cy + Math.sin(a) * rr;
      const r = minR + Math.random() * (maxR - minR);
      let ok = true;
      // sparse overlap rejection
      for (let k = placed.length - 1; k >= Math.max(0, placed.length - 30); k--) {
        const p = placed[k];
        const dx = p.x - x, dy = p.y - y;
        if (dx * dx + dy * dy < (p.r + r) * (p.r + r) * 0.85) { ok = false; break; }
      }
      if (!ok) continue;
      placed.push({ x, y, r });
      const idx = ((Math.floor(y) * W) + Math.floor(x)) * 4;
      const isFg = maskData[idx] < 128;
      const base = isFg ? plate.fg : plate.bg;
      const col = `rgb(${Math.round(jitter(base[0]))},${Math.round(jitter(base[1]))},${Math.round(jitter(base[2]))})`;
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // Soft outline
    ctx.strokeStyle = "rgba(0,0,0,0.06)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, W / 2 - 3, 0, Math.PI * 2);
    ctx.stroke();
  }, [plate, size]);

  return (
    <canvas
      ref={ref}
      style={{ width: size, height: size, borderRadius: "50%" }}
      aria-label={`Ishihara plate ${plate.id}`}
    />
  );
}
