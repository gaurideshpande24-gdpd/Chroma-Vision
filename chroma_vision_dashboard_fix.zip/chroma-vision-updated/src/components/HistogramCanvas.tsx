// HistogramCanvas: tiny per-channel RGB histogram.
import { useEffect, useRef } from "react";
import type { Histogram } from "@/lib/colorease/histogram";

export function HistogramCanvas({ data, label }: { data: Histogram | null; label: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current; if (!c || !data) return;
    const ctx = c.getContext("2d")!;
    const W = c.width = c.clientWidth * devicePixelRatio;
    const H = c.height = c.clientHeight * devicePixelRatio;
    ctx.clearRect(0, 0, W, H);
    const max = Math.max(1, ...data.r, ...data.g, ...data.b);
    const bw = W / data.bins;
    const draw = (arr: number[], color: string) => {
      ctx.fillStyle = color;
      for (let i = 0; i < arr.length; i++) {
        const h = (arr[i] / max) * H;
        ctx.fillRect(i * bw, H - h, bw - 1, h);
      }
    };
    ctx.globalCompositeOperation = "lighter";
    draw(data.r, "rgba(220,40,40,0.7)");
    draw(data.g, "rgba(40,180,60,0.7)");
    draw(data.b, "rgba(40,80,220,0.7)");
    ctx.globalCompositeOperation = "source-over";
  }, [data]);

  return (
    <div className="flex flex-col gap-1">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <canvas ref={ref} className="h-16 w-full rounded-md bg-muted/50" />
    </div>
  );
}
