
# Advanced Assistive Image Recoloring Upgrade

## Added Features
- Strong Daltonization Pipeline
- FFT Spectrum Panel
- Pixel Inspector
- K-Means Segmentation
- JPEG Compression Slider
- Histogram Support
- Edge Detection Hooks
- Multi-Image Architecture
- Accessibility Analysis Structure

## Run

npm install

npm run dev

## Important
The upgraded recoloring logic preserves the strong visible color differentiation from the old algorithm:
- error = original - simulated
- alpha = 2.8
- HSV saturation boost
- strong accessibility enhancement
